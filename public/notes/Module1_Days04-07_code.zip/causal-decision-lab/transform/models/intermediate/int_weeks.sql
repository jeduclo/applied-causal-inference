-- The calendar spine: one row per Monday, numbered 1..16.
select
    cast(week_start as date)                          as week_start,
    row_number() over (order by week_start)           as week_no
from generate_series(
    date '{{ var("first_week") }}',
    date '{{ var("last_week") }}',
    interval 7 day
) as g(week_start)
