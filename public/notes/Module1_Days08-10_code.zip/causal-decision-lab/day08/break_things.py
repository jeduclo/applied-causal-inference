# day08/break_things.py
"""
Fire drill: damage the raw data on purpose, then check which contract catches it.

    python day08/break_things.py backdate     # 50 emails recorded two weeks early
    python day08/break_things.py drop_week    # a missed load: week 5 has no orders
    python day08/break_things.py duplicate    # 100 orders loaded twice
    python day08/break_things.py orphan       # 5 orders from a customer who doesn't exist
    python day08/break_things.py restore      # reload clean data from the API

After each fault, run `dbt build --profiles-dir .` in transform/ and read the results.
The NorthMart API must be running for `restore`.
"""
import shutil
import subprocess
import sys

import duckdb

DB = "data/northmart.duckdb"

FAULTS = {
    "backdate": """
        UPDATE raw.campaign_recipients SET sent_date = '2026-02-16'
        WHERE customer_id IN (SELECT customer_id FROM raw.campaign_recipients ORDER BY customer_id LIMIT 50)
    """,
    "drop_week": """
        DELETE FROM raw.orders WHERE order_date BETWEEN '2026-02-02' AND '2026-02-08'
    """,
    "duplicate": """
        INSERT INTO raw.orders
        SELECT * REPLACE ('9999999999.0' AS _dlt_load_id)
        FROM raw.orders ORDER BY order_id LIMIT 100
    """,
    "orphan": """
        UPDATE raw.orders SET customer_id = 'C99999'
        WHERE order_id IN (SELECT order_id FROM raw.orders WHERE status = 'completed' ORDER BY order_id LIMIT 5)
    """,
}


def restore() -> None:
    """Throw away the raw data and the pipeline's memory, then reload everything."""
    con = duckdb.connect(DB)
    con.sql("DROP SCHEMA IF EXISTS raw CASCADE")
    con.close()
    shutil.rmtree(".dlt_pipelines/northmart", ignore_errors=True)
    subprocess.run([sys.executable, "api/clock.py", "2026-04-26"], check=True)
    subprocess.run([sys.executable, "day05/northmart_pipeline.py"], check=True)


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in [*FAULTS, "restore"]:
        print(__doc__)
        sys.exit(1)
    name = sys.argv[1]
    if name == "restore":
        restore()
        return
    con = duckdb.connect(DB)
    con.sql(FAULTS[name])
    con.close()
    print(f"Fault '{name}' injected into the raw schema. Now run dbt build.")


if __name__ == "__main__":
    main()
