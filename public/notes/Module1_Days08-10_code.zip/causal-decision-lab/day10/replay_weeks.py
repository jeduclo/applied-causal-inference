# day10/replay_weeks.py
"""
Capstone step 1: live through the 16 weeks as NorthMart's data team did.

Starts from an empty warehouse, then runs the full pipeline once per week,
every Sunday from 11 January to 26 April 2026. Each run loads only that week's
new orders, rebuilds the models, checks every contract, and publishes.
"""
import sys
from datetime import date, timedelta
from pathlib import Path

import polars as pl

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "pipeline"))
sys.path.insert(0, str(ROOT / "day10"))
from northmart_flow import northmart_pipeline  # noqa: E402
from reset_warehouse import reset_warehouse  # noqa: E402

FIRST_SUNDAY = date(2026, 1, 11)
N_WEEKS = 16


def snapshot(as_of: date) -> dict:
    panel = pl.read_parquet(ROOT / "data" / "published" / "panel_customer_week.parquet")
    return {
        "as_of": as_of,
        "weeks": panel["week_start"].n_unique(),
        "panel_rows": panel.height,
        "orders_so_far": int(panel["n_orders"].sum()),
        "treated_customers": int(panel.filter(pl.col("week_no") == 1)["treated"].sum()),
    }


def main() -> None:
    reset_warehouse()
    history = []
    for k in range(N_WEEKS):
        as_of = FIRST_SUNDAY + timedelta(weeks=k)
        northmart_pipeline(as_of.isoformat())
        history.append(snapshot(as_of))

    table = pl.DataFrame(history)
    with pl.Config(tbl_rows=-1):
        print(table)
    table.write_csv(ROOT / "data" / "published" / "replay_history.csv")


if __name__ == "__main__":
    main()
