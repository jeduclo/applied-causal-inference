# day10/acceptance.py
"""Capstone step 2: acceptance tests for the published Causal Data Mart."""
import json
from pathlib import Path

import polars as pl

PUB = Path("data/published")
KEY = ["customer_id", "week_start"]
results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, bool(ok), detail))


manifest = json.loads((PUB / "manifest.json").read_text())
panel = pl.read_parquet(PUB / "panel_customer_week.parquet").sort(KEY)
features = pl.read_parquet(PUB / "customer_features.parquet")

# A. The release is complete and clean
check("A1 data covers all 16 weeks", panel["week_start"].n_unique() == 16, str(manifest["data_as_of"]))
check("A2 dbt build had no errors", "ERROR=0" in manifest["dbt"], manifest["dbt"])
check("A3 one feature row per customer", features.height == features["customer_id"].n_unique() == 4000)

# B. It agrees with the independent Day 3 pipeline
day3_file = Path("data/marts/panel_customer_week.parquet")
if day3_file.exists():
    day3 = pl.read_parquet(day3_file).sort(KEY)
    same = all(
        ((panel[c].cast(pl.Float64) - day3[c].cast(pl.Float64)).abs() < 1e-6).all()
        if panel[c].dtype.is_numeric() else (panel[c] == day3[c]).all()
        for c in day3.columns
    )
    check("B1 identical to the Day 3 panel", same and panel.height == day3.height)
else:
    check("B1 identical to the Day 3 panel", False, "run Days 2-3 scripts to create the comparison file")

# C. It supports the causal analysis of Modules 2-5
cust = panel.group_by("customer_id", "treated").agg(
    pre=pl.col("n_orders").filter(pl.col("post") == 0).sum(),
    post=pl.col("n_orders").filter(pl.col("post") == 1).sum(),
)
m = cust.group_by("treated").agg(pl.col("pre").mean(), pl.col("post").mean()).sort("treated")
c, t = m.row(0, named=True), m.row(1, named=True)
naive = t["post"] / c["post"] - 1
growth_gap = (t["post"] / t["pre"] - 1) - (c["post"] / c["pre"] - 1)
check("C1 naive post-period gap reproduces Day 2", abs(naive - 1.06) < 0.01, f"{naive:+.1%}")
check("C2 difference in growth reproduces Day 2", abs(growth_gap - 0.155) < 0.005, f"{growth_gap:+.1%}")
check("C3 features balance: treated spent more pre-email",
      features.filter(pl.col("treated") == 1)["pre_revenue"].mean()
      > features.filter(pl.col("treated") == 0)["pre_revenue"].mean())

for name, ok, detail in results:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
passed = sum(ok for _, ok, _ in results)
print(f"\n{passed}/{len(results)} acceptance checks passed")
raise SystemExit(0 if passed == len(results) else 1)
