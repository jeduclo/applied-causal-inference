# day10/reset_warehouse.py
"""Empty the warehouse and the loader's memory, as on the first day of a new pipeline."""
import shutil
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parent.parent


def reset_warehouse() -> None:
    con = duckdb.connect(str(ROOT / "data" / "northmart.duckdb"))
    for schema in ["raw", "staging", "intermediate", "marts"]:
        con.sql(f"DROP SCHEMA IF EXISTS {schema} CASCADE")
    con.close()
    shutil.rmtree(ROOT / ".dlt_pipelines" / "northmart", ignore_errors=True)
    shutil.rmtree(ROOT / "data" / "published", ignore_errors=True)
    print("Warehouse emptied: raw, staging, intermediate and marts dropped; loader state cleared.")


if __name__ == "__main__":
    reset_warehouse()
