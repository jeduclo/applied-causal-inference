"""
Move the NorthMart API's simulated 'today'.

    python api/clock.py 2026-02-28    # only the 8 pre-email weeks exist
    python api/clock.py 2026-04-26    # all 16 weeks exist (the default)

The API reads the clock on every request, so no restart is needed.
"""
import sys
from datetime import date
from pathlib import Path

CLOCK = Path(__file__).resolve().parent / "clock.txt"

if len(sys.argv) != 2:
    print(__doc__)
    sys.exit(1)

new_day = date.fromisoformat(sys.argv[1])          # fails loudly on a bad date
CLOCK.write_text(new_day.isoformat())
print(f"NorthMart API 'today' is now {new_day}")
