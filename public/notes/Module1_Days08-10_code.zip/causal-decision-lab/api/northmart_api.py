"""
NorthMart REST API (simulated). Provided for the course: you don't need to edit it.

Start it in its own terminal from the repository root:
    python api/northmart_api.py

It serves the files in data/raw/ as a paginated JSON API at http://127.0.0.1:8000
(interactive docs at http://127.0.0.1:8000/docs).

Like a real company API it:
  - requires an API key in the X-API-Key header
  - returns results in pages (page, page_size, next_page)
  - nests related fields inside objects
  - only shows orders up to the simulated "today" stored in api/clock.txt
    (move the clock with: python api/clock.py 2026-04-26)
"""
from datetime import date
from pathlib import Path

import polars as pl
import uvicorn
from fastapi import Depends, FastAPI, Header, HTTPException, Query

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
CLOCK = Path(__file__).resolve().parent / "clock.txt"
API_KEY = "northmart-demo-key"
MAX_PAGE_SIZE = 1000

app = FastAPI(title="NorthMart API", version="1.0")

customers = pl.read_csv(RAW / "customers.csv", try_parse_dates=True)
products = pl.read_csv(RAW / "products.csv")
orders = pl.read_csv(RAW / "orders.csv", try_parse_dates=True)
campaign = pl.read_csv(RAW / "email_campaign.csv", try_parse_dates=True)


def today() -> date:
    """The simulated 'today'. Orders after this date have not happened yet."""
    if CLOCK.exists():
        return date.fromisoformat(CLOCK.read_text().strip())
    return date(2026, 4, 26)


def check_key(x_api_key: str | None = Header(default=None)) -> None:
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Missing or invalid X-API-Key header")


def paginate(rows: list[dict], page: int, page_size: int) -> dict:
    start = (page - 1) * page_size
    chunk = rows[start:start + page_size]
    has_more = start + page_size < len(rows)
    return {
        "page": page,
        "page_size": page_size,
        "total": len(rows),
        "next_page": page + 1 if has_more else None,
        "data": chunk,
    }


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "today": today().isoformat()}


@app.get("/customers", dependencies=[Depends(check_key)])
def get_customers(page: int = Query(1, ge=1), page_size: int = Query(500, ge=1, le=MAX_PAGE_SIZE)) -> dict:
    rows = [
        {
            "customer_id": r["customer_id"],
            "signup_date": r["signup_date"].isoformat(),
            "profile": {"region": r["region"], "age": r["age"]},
            "is_loyalty": r["is_loyalty"],
        }
        for r in customers.iter_rows(named=True)
    ]
    return paginate(rows, page, page_size)


@app.get("/products", dependencies=[Depends(check_key)])
def get_products() -> dict:
    return {"data": products.to_dicts()}


@app.get("/orders", dependencies=[Depends(check_key)])
def get_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(500, ge=1, le=MAX_PAGE_SIZE),
    updated_since: str | None = Query(None, description="ISO timestamp; only orders updated after it"),
) -> dict:
    visible = orders.filter(pl.col("order_date") <= today())
    rows = []
    for r in visible.iter_rows(named=True):
        updated_at = f"{r['order_date'].isoformat()}T23:00:00Z"
        if updated_since and updated_at <= updated_since:
            continue
        rows.append({
            "order_id": r["order_id"],
            "customer_id": r["customer_id"],
            "order_date": r["order_date"].isoformat(),
            "status": r["status"],
            "updated_at": updated_at,
            "line": {
                "product_id": r["product_id"],
                "quantity": r["quantity"],
                "unit_price": r["unit_price"],
                "discount_pct": r["discount_pct"],
            },
        })
    return paginate(rows, page, page_size)


@app.get("/campaigns/{campaign_id}/recipients", dependencies=[Depends(check_key)])
def get_recipients(campaign_id: str) -> dict:
    sent = campaign.filter((pl.col("campaign_id") == campaign_id) & (pl.col("sent_date") <= today()))
    if campaign.filter(pl.col("campaign_id") == campaign_id).height == 0:
        raise HTTPException(status_code=404, detail=f"Unknown campaign {campaign_id}")
    return {
        "campaign_id": campaign_id,
        "data": [{"customer_id": r["customer_id"], "sent_date": r["sent_date"].isoformat()}
                 for r in sent.iter_rows(named=True)],
    }


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
