# day02/naive_comparison.py
"""Mini-project: how different do emailed and non-emailed customers look, before and after?"""
import polars as pl

SENT = pl.date(2026, 3, 2)

customers = pl.read_parquet("data/clean/customers.parquet")
orders = pl.read_parquet("data/clean/orders.parquet")
campaign = pl.read_parquet("data/clean/email_campaign.parquet")

# 1. Orders per customer, before and after the email date
per_customer = orders.group_by("customer_id").agg(
    orders_pre=(pl.col("order_date") < SENT).sum(),
    orders_post=(pl.col("order_date") >= SENT).sum(),
)

# 2. One row per customer, treatment flag, zeros for non-buyers
analysis = (
    customers
    .join(campaign.select("customer_id", treated=pl.lit(1)), on="customer_id", how="left")
    .join(per_customer, on="customer_id", how="left")
    .with_columns(
        pl.col("treated").fill_null(0),
        pl.col("orders_pre", "orders_post").fill_null(0),
    )
)

# 3. Compare group means
summary = (analysis.group_by("treated")
           .agg(n=pl.len(),
                orders_pre=pl.col("orders_pre").mean(),
                orders_post=pl.col("orders_post").mean(),
                loyalty_share=pl.col("is_loyalty").mean())
           .sort("treated"))
print(summary)

t = summary.filter(pl.col("treated") == 1).row(0, named=True)
c = summary.filter(pl.col("treated") == 0).row(0, named=True)

naive = t["orders_post"] / c["orders_post"] - 1
pre_gap = t["orders_pre"] / c["orders_pre"] - 1
growth_t = t["orders_post"] / t["orders_pre"] - 1
growth_c = c["orders_post"] / c["orders_pre"] - 1

print(f"\nNaive 'effect' (post-period gap):    {naive:+.0%}")
print(f"Gap BEFORE the email was even sent:  {pre_gap:+.0%}")
print(f"Growth, emailed customers:           {growth_t:+.1%}")
print(f"Growth, other customers:             {growth_c:+.1%}")
print(f"Difference in growth:                {growth_t - growth_c:+.1%}")
print("\nThe simulation's TRUE effect is +15% more orders.")
