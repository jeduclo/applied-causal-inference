# day02/expressions.py
import polars as pl

orders = pl.read_csv("data/raw/orders.csv", try_parse_dates=True)

# 1. select: keep some columns
print(orders.select("order_id", "customer_id", "unit_price").head(3))

# 2. filter: keep some rows
big = orders.filter(pl.col("unit_price") > 200)
print("Lines over $200:", big.height)

# 3. with_columns: add a new column built from others
orders = orders.with_columns(
    revenue=pl.col("quantity") * pl.col("unit_price"),
)
print(orders.select("quantity", "unit_price", "revenue").head(3))

# 4. Several conditions at once
discounted_big = orders.filter(
    (pl.col("discount_pct") > 0) & (pl.col("unit_price") > 100)
)
print("Discounted lines over $100:", discounted_big.height)

# 5. Conditional column: when / then / otherwise
orders = orders.with_columns(
    period=pl.when(pl.col("order_date") >= pl.date(2026, 3, 2))
             .then(pl.lit("post"))
             .otherwise(pl.lit("pre"))
)
print(orders.group_by("period").len().sort("period"))
