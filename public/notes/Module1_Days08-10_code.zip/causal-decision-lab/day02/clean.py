# day02/clean.py
"""Clean the raw NorthMart files and save them as Parquet in data/clean/."""
from pathlib import Path

import polars as pl

RAW = Path("data/raw")
CLEAN = Path("data/clean")


def clean_customers(df: pl.DataFrame) -> pl.DataFrame:
    return df.with_columns(
        region=pl.col("region").str.strip_chars().str.to_uppercase().fill_null("UNKNOWN")
    )


def clean_orders(df: pl.DataFrame) -> pl.DataFrame:
    return (
        df.unique(maintain_order=True)                 # drop exact duplicate rows
          .filter(pl.col("status") == "completed")     # cancelled orders never happened
          .with_columns(revenue=(pl.col("quantity") * pl.col("unit_price")).round(2))
    )


def main() -> None:
    CLEAN.mkdir(parents=True, exist_ok=True)

    customers_raw = pl.read_csv(RAW / "customers.csv", try_parse_dates=True)
    orders_raw = pl.read_csv(RAW / "orders.csv", try_parse_dates=True)
    products = pl.read_csv(RAW / "products.csv")
    campaign = pl.read_csv(RAW / "email_campaign.csv", try_parse_dates=True)

    customers = clean_customers(customers_raw)
    orders = clean_orders(orders_raw)

    print("Regions before:", sorted(customers_raw["region"].drop_nulls().unique().to_list()))
    print("Regions after: ", sorted(customers["region"].unique().to_list()))
    print(f"Order lines: {orders_raw.height:,} raw -> {orders.height:,} clean")

    # Checks: stop loudly if something is wrong
    assert orders["order_id"].is_unique().all(), "order_id should be unique after cleaning"
    assert customers["customer_id"].is_unique().all(), "customer_id should be unique"
    assert orders["revenue"].min() > 0, "revenue should be positive"

    customers.write_parquet(CLEAN / "customers.parquet")
    orders.write_parquet(CLEAN / "orders.parquet")
    products.write_parquet(CLEAN / "products.parquet")
    campaign.write_parquet(CLEAN / "email_campaign.parquet")
    print("Saved 4 Parquet files to", CLEAN)


if __name__ == "__main__":
    main()
