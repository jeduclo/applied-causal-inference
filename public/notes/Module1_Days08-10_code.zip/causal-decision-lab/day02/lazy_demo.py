# day02/lazy_demo.py
import polars as pl

# scan_parquet builds a plan; nothing is read yet
plan = (
    pl.scan_parquet("data/clean/orders.parquet")
      .filter(pl.col("order_date") >= pl.date(2026, 3, 2))
      .group_by("customer_id")
      .agg(post_revenue=pl.col("revenue").sum())
)
print(plan.explain())       # see the optimised plan
result = plan.collect()     # now Polars does the work
print(result.sort("post_revenue", descending=True).head(5))
