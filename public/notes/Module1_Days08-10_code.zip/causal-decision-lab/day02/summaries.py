# day02/summaries.py
import polars as pl

orders = pl.read_parquet("data/clean/orders.parquet")
customers = pl.read_parquet("data/clean/customers.parquet")
campaign = pl.read_parquet("data/clean/email_campaign.parquet")

# 1. One number for the whole table
print(f"Total revenue: ${orders['revenue'].sum():,.0f}")

# 2. group_by + agg: one row per region... but region lives in customers, so join first
orders_c = orders.join(customers, on="customer_id", how="left")
by_region = (orders_c.group_by("region")
             .agg(n_orders=pl.len(), revenue=pl.col("revenue").sum().round(0).cast(pl.Int64))
             .sort("revenue", descending=True))
print(by_region)

# 3. Customer-level outcome table
per_customer = orders.group_by("customer_id").agg(
    n_orders=pl.col("order_id").n_unique(),
    revenue=pl.col("revenue").sum(),
    first_order=pl.col("order_date").min(),
)
print(per_customer.head())
print("Customers with at least one order:", per_customer.height, "of", customers.height)

# 4. The treatment lives in its own table: left join + fill the gaps with 0
customers_t = (customers
               .join(campaign.select("customer_id", "sent_date"), on="customer_id", how="left")
               .with_columns(treated=pl.col("sent_date").is_not_null().cast(pl.Int8)))
print(customers_t.group_by("treated").len().sort("treated"))

# 5. Keep customers who never ordered! Start from customers, not orders.
analysis = (customers_t
            .join(per_customer, on="customer_id", how="left")
            .with_columns(pl.col("n_orders", "revenue").fill_null(0)))
print("Rows in analysis table:", analysis.height)
