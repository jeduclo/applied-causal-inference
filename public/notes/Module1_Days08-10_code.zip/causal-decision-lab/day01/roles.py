# day01/roles.py
# One real NorthMart customer, written by hand as a Python dictionary
customer = {
    "customer_id": "C00004",
    "region": "ON",
    "age": 22,
    "is_loyalty": True,
    "orders_before": 7,     # weeks 1-8
    "orders_after": 2,      # weeks 9-16
    "got_email": True,
}

# What role does each column play in a causal question?
roles = {
    "customer_id": "unit",
    "region": "covariate",
    "age": "covariate",
    "is_loyalty": "covariate",
    "orders_before": "pre-treatment outcome",
    "orders_after": "outcome",
    "got_email": "treatment",
}

for column, role in roles.items():
    print(f"{column:<15} {role:<22} value = {customer[column]}")

change = customer["orders_after"] - customer["orders_before"]
print(f"\nChange in orders: {change:+d}")
