# day01/data_dictionary.py
"""Profile every raw file and record the causal role of each column."""
from pathlib import Path

import polars as pl

RAW = Path("data/raw")

ROLES = {
    "customer_id": "unit",
    "signup_date": "covariate (pre-treatment)",
    "region": "covariate (pre-treatment)",
    "age": "covariate (pre-treatment)",
    "is_loyalty": "covariate (pre-treatment)",
    "order_id": "identifier",
    "order_date": "time",
    "product_id": "identifier",
    "quantity": "outcome ingredient",
    "unit_price": "outcome ingredient",
    "discount_pct": "possible mediator / other treatment",
    "status": "filter",
    "category": "covariate",
    "base_price": "covariate",
    "campaign_id": "treatment label",
    "sent_date": "treatment timing",
}


def profile(name: str, df: pl.DataFrame) -> list[dict]:
    rows = []
    for col in df.columns:
        rows.append({
            "table": name,
            "column": col,
            "dtype": str(df[col].dtype),
            "nulls": df[col].null_count(),
            "unique": df[col].n_unique(),
            "example": str(df[col].drop_nulls()[0]),
            "role": ROLES.get(col, "?"),
        })
    return rows


def main() -> None:
    all_rows = []
    for path in sorted(RAW.glob("*.csv")):
        df = pl.read_csv(path, try_parse_dates=True)
        all_rows += profile(path.stem, df)

    dictionary = pl.DataFrame(all_rows)
    with pl.Config(tbl_rows=-1, tbl_width_chars=140):
        print(dictionary)

    # Save a Markdown version for the docs/ folder
    lines = ["| table | column | dtype | nulls | unique | example | role |",
             "|---|---|---|---|---|---|---|"]
    for r in dictionary.iter_rows(named=True):
        lines.append(f"| {r['table']} | {r['column']} | {r['dtype']} | {r['nulls']} | "
                     f"{r['unique']} | {r['example']} | {r['role']} |")
    Path("docs").mkdir(exist_ok=True)
    Path("docs/data_dictionary.md").write_text("# NorthMart data dictionary\n\n" + "\n".join(lines) + "\n")
    print("\nSaved docs/data_dictionary.md")


if __name__ == "__main__":
    main()
