# day01/first_look.py
import polars as pl

customers = pl.read_csv("data/raw/customers.csv", try_parse_dates=True)
orders = pl.read_csv("data/raw/orders.csv", try_parse_dates=True)
campaign = pl.read_csv("data/raw/email_campaign.csv", try_parse_dates=True)

print("customers:", customers.shape)
print("orders:   ", orders.shape)
print("campaign: ", campaign.shape)

print(customers.head())
print(orders.schema)
print(orders.select("quantity", "unit_price", "discount_pct").describe())

share = campaign.height / customers.height
print(f"\nShare of customers who got the email: {share:.1%}")
print("First order date:", orders["order_date"].min())
print("Last order date: ", orders["order_date"].max())
