# day01/hello_causal.py
question = "Did the spring email make customers buy more?"
treatment = "received the SPRING26 email"
outcome = "number of orders in the 8 weeks after 2 March 2026"

print("Causal question:", question)
print("Treatment:", treatment)
print("Outcome:", outcome)
