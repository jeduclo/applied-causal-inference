# day05/northmart_pipeline.py
"""Mini-project: one dlt source for the whole NorthMart API, loaded into the `raw` schema."""
from pathlib import Path

import dlt
import requests

DB = str(Path("data/northmart.duckdb").resolve())


def get_pages(base_url: str, api_key: str, endpoint: str, **params):
    page = 1
    while page is not None:
        r = requests.get(f"{base_url}/{endpoint}", headers={"X-API-Key": api_key}, timeout=30,
                         params={"page": page, "page_size": 1000, **params})
        r.raise_for_status()
        body = r.json()
        yield body["data"]
        page = body.get("next_page")


def get_pages_once(base_url: str, api_key: str, endpoint: str) -> list[dict]:
    r = requests.get(f"{base_url}/{endpoint}", headers={"X-API-Key": api_key}, timeout=30)
    r.raise_for_status()
    return r.json()["data"]


@dlt.source(name="northmart")
def northmart_source(base_url: str = dlt.config.value, api_key: str = dlt.secrets.value):
    """base_url comes from .dlt/config.toml, api_key from .dlt/secrets.toml (or env vars)."""

    @dlt.resource(primary_key="customer_id", write_disposition="replace")
    def customers():
        yield from get_pages(base_url, api_key, "customers")

    @dlt.resource(primary_key="product_id", write_disposition="replace")
    def products():
        yield get_pages_once(base_url, api_key, "products")

    @dlt.resource(primary_key="customer_id", write_disposition="replace")
    def campaign_recipients():
        body = get_pages_once(base_url, api_key, "campaigns/SPRING26/recipients")
        yield [{**row, "campaign_id": "SPRING26"} for row in body]

    @dlt.resource(primary_key="order_id", write_disposition="merge")
    def orders(updated_at=dlt.sources.incremental("updated_at", initial_value="2026-01-01T00:00:00Z")):
        since = updated_at.start_value
        yield from get_pages(base_url, api_key, "orders", updated_since=since)

    return customers, products, campaign_recipients, orders


def main() -> None:
    pipeline = dlt.pipeline(
        pipeline_name="northmart",
        destination=dlt.destinations.duckdb(DB),
        pipelines_dir=".dlt_pipelines",
        dataset_name="raw",
    )
    pipeline.run(northmart_source())

    with pipeline.sql_client() as client:
        existing = {r[0] for r in client.execute_sql(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'raw'")}
        for table in ["customers", "products", "campaign_recipients", "orders"]:
            if table not in existing:      # dlt only creates a table once it has received rows
                print(f"raw.{table:<20}  (no rows yet)")
                continue
            n = client.execute_sql(f"SELECT COUNT(*) FROM {table}")[0][0]
            print(f"raw.{table:<20} {n:>7,} rows")


if __name__ == "__main__":
    main()
