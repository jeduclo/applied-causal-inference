# day05/orders_resource.py
from pathlib import Path

import dlt
import requests

BASE = "http://127.0.0.1:8000"
HEADERS = {"X-API-Key": "northmart-demo-key"}


@dlt.resource(name="orders", write_disposition="replace")
def orders():
    """A resource is a generator: it yields pages, dlt does the rest."""
    page = 1
    while page is not None:
        r = requests.get(f"{BASE}/orders", headers=HEADERS,
                         params={"page": page, "page_size": 1000}, timeout=30)
        r.raise_for_status()
        body = r.json()
        yield body["data"]
        page = body["next_page"]


pipeline = dlt.pipeline(
    pipeline_name="orders_demo",
    destination=dlt.destinations.duckdb(str(Path("data/northmart.duckdb").resolve())),
    pipelines_dir=".dlt_pipelines",   # keep pipeline state inside the project
    dataset_name="practice",
)
print(pipeline.run(orders()))

with pipeline.sql_client() as client:
    print(client.execute_sql("SELECT COUNT(*), COUNT(DISTINCT order_id) FROM orders"))
    cols = client.execute_sql("""
        SELECT column_name, data_type FROM information_schema.columns
        WHERE table_schema = 'practice' AND table_name = 'orders' ORDER BY ordinal_position
    """)
    for name, dtype in cols:
        print(f"  {name:<22} {dtype}")
