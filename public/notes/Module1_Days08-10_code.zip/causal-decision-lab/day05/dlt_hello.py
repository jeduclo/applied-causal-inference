# day05/dlt_hello.py
from pathlib import Path

import dlt

# 1. Any list of dicts (or a generator of them) can be loaded
rates = [
    {"week": "2026-03-02", "segment": "loyalty", "orders_per_customer": 0.52},
    {"week": "2026-03-02", "segment": "regular", "orders_per_customer": 0.21},
]

# 2. A pipeline = a name + a destination + a dataset (schema) to write into
pipeline = dlt.pipeline(
    pipeline_name="hello",
    destination=dlt.destinations.duckdb(str(Path("data/northmart.duckdb").resolve())),
    pipelines_dir=".dlt_pipelines",   # keep pipeline state inside the project
    dataset_name="practice",
)

# 3. run() infers the schema, creates the table and loads the rows
info = pipeline.run(rates, table_name="weekly_rates")
print(info)

# 4. Read it back
with pipeline.sql_client() as client:
    print(client.execute_sql("SELECT * FROM weekly_rates"))
