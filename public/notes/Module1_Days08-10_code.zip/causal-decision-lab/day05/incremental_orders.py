# day05/incremental_orders.py
"""Load only what is new, and never load the same order twice."""
from pathlib import Path

import dlt
import requests

BASE = "http://127.0.0.1:8000"
HEADERS = {"X-API-Key": "northmart-demo-key"}


@dlt.resource(name="orders", primary_key="order_id", write_disposition="merge")
def orders(updated_at=dlt.sources.incremental("updated_at", initial_value="2026-01-01T00:00:00Z")):
    # dlt remembers the largest updated_at it has seen and gives it back to us next run.
    # Read it ONCE: last_value keeps moving while pages arrive during this run.
    since = updated_at.start_value
    print(f"  asking the API for orders updated after {since}")
    page = 1
    while page is not None:
        r = requests.get(f"{BASE}/orders", headers=HEADERS, timeout=30,
                         params={"page": page, "page_size": 1000, "updated_since": since})
        r.raise_for_status()
        body = r.json()
        yield body["data"]
        page = body["next_page"]


pipeline = dlt.pipeline(
    pipeline_name="incremental_demo",
    destination=dlt.destinations.duckdb(str(Path("data/northmart.duckdb").resolve())),
    pipelines_dir=".dlt_pipelines",
    dataset_name="practice_incremental",
)
pipeline.run(orders())

with pipeline.sql_client() as client:
    n, n_ids, last = client.execute_sql(
        "SELECT COUNT(*), COUNT(DISTINCT order_id), MAX(order_date) FROM orders")[0]
    print(f"orders table: {n:,} rows, {n_ids:,} distinct order_ids, latest order {last}")
