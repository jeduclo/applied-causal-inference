{#
  Customer features "as of" the email date.
  The orders relation is an argument so a test can call this macro on
  orders that physically stop before the email date, and compare.
#}
{% macro customer_features_from(orders_relation) %}
with pre_orders as (
    select *
    from {{ orders_relation }}
    where order_date < date '{{ var("campaign_date") }}'
),
per_customer as (
    select
        customer_id,
        count(distinct order_id)                                   as pre_orders,
        sum(revenue)                                               as pre_revenue,
        count(distinct date_trunc('week', order_date))             as pre_active_weeks,
        avg(case when discount_pct > 0 then 1.0 else 0.0 end)      as pre_discount_share,
        max(order_date)                                            as last_order
    from pre_orders
    group by customer_id
)
select
    c.customer_id,
    cast(r.customer_id is not null as integer)                                     as treated,
    c.region,
    c.age,
    cast(c.is_loyalty as integer)                                                  as is_loyalty,
    cast(date_diff('day', c.signup_date, date '{{ var("campaign_date") }}') as bigint) as tenure_days,
    cast(coalesce(p.pre_orders, 0) as bigint)                                      as pre_orders,
    round(coalesce(p.pre_revenue, 0), 2)                                           as pre_revenue,
    cast(coalesce(p.pre_active_weeks, 0) as bigint)                                as pre_active_weeks,
    round(p.pre_discount_share, 4)                                                 as pre_discount_share,
    cast(date_diff('day', p.last_order, date '{{ var("campaign_date") }}') as bigint) as days_since_last_order
from {{ ref('stg_customers') }} as c
left join per_customer as p using (customer_id)
left join {{ ref('stg_campaign_recipients') }} as r
    on r.customer_id = c.customer_id and r.campaign_id = '{{ var("campaign_id") }}'
{% endmacro %}
