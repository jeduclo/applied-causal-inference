-- The Module 1 deliverable: one row per customer per week, ready for causal analysis.
-- Grain: customer_id x week_start. Treatment: the {{ var("campaign_id") }} email.

with spine as (
    select c.customer_id, w.week_start, w.week_no
    from {{ ref('stg_customers') }} as c
    cross join {{ ref('int_weeks') }} as w
),

filled as (
    select
        s.*,
        coalesce(o.n_orders, 0)  as n_orders,
        coalesce(o.revenue, 0)   as revenue
    from spine as s
    left join {{ ref('int_customer_weekly_orders') }} as o using (customer_id, week_start)
),

recipients as (
    select customer_id, sent_date
    from {{ ref('stg_campaign_recipients') }}
    where campaign_id = '{{ var("campaign_id") }}'
)

select
    f.customer_id,
    f.week_start,
    f.week_no,
    f.week_no - {{ var("campaign_week") }}                         as event_week,
    cast(r.customer_id is not null as integer)                     as treated,
    cast(f.week_no >= {{ var("campaign_week") }} as integer)       as post,
    cast(r.customer_id is not null
         and f.week_start >= r.sent_date as integer)               as treated_post,
    f.n_orders,
    round(f.revenue, 2)                                            as revenue,
    c.region,
    c.age,
    cast(c.is_loyalty as integer)                                  as is_loyalty,
    cast(sum(f.n_orders) filter (where f.week_no < {{ var("campaign_week") }})
        over (partition by f.customer_id) as bigint)               as pre_orders,
    round(sum(f.revenue) filter (where f.week_no < {{ var("campaign_week") }})
        over (partition by f.customer_id), 2)                      as pre_revenue
from filled as f
join {{ ref('stg_customers') }} as c using (customer_id)
left join recipients as r using (customer_id)
