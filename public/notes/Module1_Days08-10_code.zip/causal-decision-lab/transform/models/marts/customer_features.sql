-- One row per customer, for the estimation modules (matching, weighting, causal ML).
{{ customer_features_from(ref('stg_orders')) }}
