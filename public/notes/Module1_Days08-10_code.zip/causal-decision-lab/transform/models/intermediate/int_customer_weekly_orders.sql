-- Outcomes per customer-week, only where at least one order exists.
select
    customer_id,
    cast(date_trunc('week', order_date) as date)      as week_start,
    count(distinct order_id)                          as n_orders,
    sum(revenue)                                      as revenue
from {{ ref('stg_orders') }}
group by all
