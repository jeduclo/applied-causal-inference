-- The calendar spine: one row per Monday, numbered 1, 2, 3...
-- It stops at the last week that has data, so a weekly pipeline run in, say, February
-- doesn't create empty "future" weeks (which the completeness contract would reject).
with bounds as (
    select least(
        date '{{ var("last_week") }}',
        cast(date_trunc('week', max(order_date)) as date)
    ) as last_monday
    from {{ ref('stg_orders') }}
)
select
    cast(g.week_start as date)                        as week_start,
    row_number() over (order by g.week_start)         as week_no
from bounds,
     generate_series(date '{{ var("first_week") }}', bounds.last_monday, interval 7 day) as g(week_start)
