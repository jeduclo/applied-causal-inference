select product_id, category, base_price
from {{ source('raw', 'products') }}
