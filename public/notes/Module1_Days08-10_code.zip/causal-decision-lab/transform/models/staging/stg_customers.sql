-- One row per customer. Region codes cleaned; missing region kept as UNKNOWN.
select
    customer_id,
    cast(signup_date as date)                                  as signup_date,
    coalesce(upper(trim(profile__region)), 'UNKNOWN')          as region,
    cast(profile__age as integer)                              as age,
    cast(is_loyalty as boolean)                                as is_loyalty
from {{ source('raw', 'customers') }}
