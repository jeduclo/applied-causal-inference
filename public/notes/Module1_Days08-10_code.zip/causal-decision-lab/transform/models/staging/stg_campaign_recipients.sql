-- Customers who received a campaign email, with the send date.
-- Before the first email is sent, dlt has not created raw.campaign_recipients yet
-- (it only creates tables that received rows). In that case: an empty table, nobody treated.
{% set recipients = adapter.get_relation(
       database=source('raw', 'campaign_recipients').database,
       schema=source('raw', 'campaign_recipients').schema,
       identifier=source('raw', 'campaign_recipients').identifier) %}

{% if recipients is not none %}
select
    customer_id,
    campaign_id,
    cast(sent_date as date) as sent_date
from {{ source('raw', 'campaign_recipients') }}
{% else %}
select
    cast(null as varchar) as customer_id,
    cast(null as varchar) as campaign_id,
    cast(null as date)    as sent_date
where false
{% endif %}
