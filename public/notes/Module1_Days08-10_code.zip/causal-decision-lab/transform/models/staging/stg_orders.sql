-- One row per completed order. Cancelled orders never happened, so they are removed here.
with ranked as (
    select
        *,
        row_number() over (partition by order_id order by _dlt_load_id desc) as rn
    from {{ source('raw', 'orders') }}
)
select
    order_id,
    customer_id,
    cast(order_date as date)                                   as order_date,
    line__product_id                                           as product_id,
    line__quantity                                             as quantity,
    line__unit_price                                           as unit_price,
    line__discount_pct                                         as discount_pct,
    round(line__quantity * line__unit_price, 2)                as revenue
from ranked
where rn = 1                       -- safety net: one row per order_id
  and status = 'completed'
