-- COMPLETENESS CONTRACT: NorthMart sells every week. A week with zero orders
-- almost always means a load was missed (e.g. a broken incremental cursor).
select week_start, sum(n_orders) as orders
from {{ ref('panel_customer_week') }}
group by week_start
having sum(n_orders) = 0
