-- TREATMENT-TIMING CONTRACT: every recipient of the campaign got it on the official date.
-- A backdated or late send would silently mix treatment timing.
select customer_id, sent_date
from {{ ref('stg_campaign_recipients') }}
where campaign_id = '{{ var("campaign_id") }}'
  and sent_date != date '{{ var("campaign_date") }}'
