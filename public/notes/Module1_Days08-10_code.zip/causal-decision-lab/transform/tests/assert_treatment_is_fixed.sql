-- TREATMENT CONTRACT: the treatment group is a property of the customer, not of the week.
select customer_id
from {{ ref('panel_customer_week') }}
group by customer_id
having count(distinct treated) > 1
