-- Causal validity: nobody can be "treated" before the email was sent.
select customer_id, week_start
from {{ ref('panel_customer_week') }}
where treated_post = 1 and post = 0
