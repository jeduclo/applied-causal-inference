-- LEAKAGE CONTRACT ("time travel" test).
-- Rebuild the features from orders that physically end before the email date.
-- If any feature changes, it was using post-treatment information.
{% set truncated_orders %}
    (select * from {{ ref('stg_orders') }} where order_date < date '{{ var("campaign_date") }}')
{% endset %}

with as_built as (
    select * from {{ ref('customer_features') }}
),
time_travel as (
    {{ customer_features_from(truncated_orders) }}
),
differences as (
    (select 'only in as_built' as side, * from as_built
     except select 'only in as_built', * from time_travel)
    union all
    (select 'only in time_travel' as side, * from time_travel
     except select 'only in time_travel', * from as_built)
)
select * from differences
