-- Panel revenue must equal order revenue (to the cent, allowing for rounding).
select
    (select sum(revenue) from {{ ref('panel_customer_week') }}) as panel_revenue,
    (select sum(revenue) from {{ ref('stg_orders') }})          as order_revenue
where abs(panel_revenue - order_revenue) >= 1
