-- Every customer must appear in every week. Returns rows (= failure) if the count is off.
select count(*) as panel_rows
from {{ ref('panel_customer_week') }}
having count(*) != (select count(*) from {{ ref('stg_customers') }})
                  * (select count(*) from {{ ref('int_weeks') }})
