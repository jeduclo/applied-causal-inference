-- OVERLAP (POSITIVITY) WARNING: every region needs both emailed and non-emailed customers,
-- otherwise there is nobody to compare with. A warning, not an error: the analyst decides.
{{ config(severity='warn') }}

select
    region,
    sum(treated)            as treated_customers,
    sum(1 - treated)        as control_customers
from {{ ref('customer_features') }}
group by region
having sum(treated) < 30 or sum(1 - treated) < 30
