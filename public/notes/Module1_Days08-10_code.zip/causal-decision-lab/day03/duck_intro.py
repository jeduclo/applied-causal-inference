# day03/duck_intro.py
import duckdb

# 1. SQL straight on a file: no loading step
print(duckdb.sql("SELECT COUNT(*) AS n_lines FROM 'data/clean/orders.parquet'"))

# 2. A familiar GROUP BY, this time on the raw CSV
print(duckdb.sql("""
    SELECT status, COUNT(*) AS n, ROUND(SUM(quantity * unit_price)) AS revenue
    FROM 'data/raw/orders.csv'
    GROUP BY status
"""))

# 3. Join two files
print(duckdb.sql("""
    SELECT c.region, COUNT(DISTINCT o.customer_id) AS buyers
    FROM 'data/clean/orders.parquet' AS o
    JOIN 'data/clean/customers.parquet' AS c USING (customer_id)
    GROUP BY c.region
    ORDER BY buyers DESC
"""))

# 4. Hand a result to Polars
df = duckdb.sql("SELECT * FROM 'data/clean/customers.parquet' WHERE is_loyalty").pl()
print(type(df), df.shape)
