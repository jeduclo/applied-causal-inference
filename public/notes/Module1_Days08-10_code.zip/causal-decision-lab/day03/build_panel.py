# day03/build_panel.py
"""Mini-project: build, check and export the customer x week panel."""
from pathlib import Path

import duckdb

con = duckdb.connect("data/northmart.duckdb")
con.sql("CREATE SCHEMA IF NOT EXISTS marts")
con.sql(Path("sql/panel_customer_week.sql").read_text())


def scalar(sql: str):
    return con.sql(sql).fetchall()[0][0]


# ---- Checks: each one is a claim about the data that must be true ----
checks = {
    "one row per customer-week":
        scalar("SELECT COUNT(*) FROM marts.panel_customer_week")
        == scalar("SELECT COUNT(*) FROM clean.customers") * 16,
    "no duplicate keys":
        scalar("SELECT COUNT(*) - COUNT(DISTINCT (customer_id, week_start)) FROM marts.panel_customer_week") == 0,
    "no missing outcomes":
        scalar("SELECT COUNT(*) FROM marts.panel_customer_week WHERE n_orders IS NULL OR revenue IS NULL") == 0,
    "revenue matches clean orders":
        abs(scalar("SELECT SUM(revenue) FROM marts.panel_customer_week")
            - scalar("SELECT SUM(revenue) FROM clean.orders")) < 1,
    "treated_post only after the email":
        scalar("SELECT COUNT(*) FROM marts.panel_customer_week WHERE treated_post = 1 AND post = 0") == 0,
    "pre_orders constant within customer":
        scalar("""SELECT COUNT(*) FROM (SELECT customer_id FROM marts.panel_customer_week
                  GROUP BY customer_id HAVING COUNT(DISTINCT pre_orders) > 1)""") == 0,
}
for name, ok in checks.items():
    print(f"[{'PASS' if ok else 'FAIL'}] {name}")
assert all(checks.values()), "Fix the failing checks before using the panel."

# ---- A first look at the panel ----
print(con.sql("""
    SELECT treated, post,
           COUNT(DISTINCT customer_id)  AS customers,
           ROUND(AVG(n_orders), 3)      AS orders_per_week,
           ROUND(AVG(revenue), 2)       AS revenue_per_week
    FROM marts.panel_customer_week
    GROUP BY treated, post
    ORDER BY treated, post
"""))

Path("data/marts").mkdir(parents=True, exist_ok=True)
con.sql("COPY marts.panel_customer_week TO 'data/marts/panel_customer_week.parquet' (FORMAT parquet)")
print("Exported data/marts/panel_customer_week.parquet")
con.close()
