# day03/windows.py
import duckdb

con = duckdb.connect("data/northmart.duckdb")

weekly = """
    SELECT customer_id,
           date_trunc('week', order_date)::DATE AS week_start,
           COUNT(*) AS n_orders
    FROM clean.orders
    WHERE customer_id = 'C00004'
    GROUP BY ALL
"""

# 1. LAG: last week's value next to this week's
print(con.sql(f"""
    SELECT *, LAG(n_orders) OVER (PARTITION BY customer_id ORDER BY week_start) AS prev_orders
    FROM ({weekly})
    ORDER BY week_start
"""))

# 2. Running total
print(con.sql(f"""
    SELECT *, SUM(n_orders) OVER (PARTITION BY customer_id ORDER BY week_start) AS cumulative
    FROM ({weekly})
    ORDER BY week_start
"""))

# 3. A pre-period average repeated on every row of the customer (a filtered window)
print(con.sql(f"""
    SELECT *,
           AVG(n_orders) FILTER (WHERE week_start < DATE '2026-03-02')
               OVER (PARTITION BY customer_id) AS pre_avg_active_weeks
    FROM ({weekly})
    ORDER BY week_start
"""))
con.close()
