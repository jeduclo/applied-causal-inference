# day03/build_warehouse.py
"""Load the clean Parquet files into a persistent DuckDB database: data/northmart.duckdb"""
import duckdb

TABLES = ["customers", "orders", "products", "email_campaign"]

con = duckdb.connect("data/northmart.duckdb")
con.sql("CREATE SCHEMA IF NOT EXISTS clean")
for t in TABLES:
    con.sql(f"CREATE OR REPLACE TABLE clean.{t} AS SELECT * FROM 'data/clean/{t}.parquet'")
    n = con.sql(f"SELECT COUNT(*) FROM clean.{t}").fetchall()[0][0]
    print(f"clean.{t:<15} {n:>7,} rows")
con.close()
