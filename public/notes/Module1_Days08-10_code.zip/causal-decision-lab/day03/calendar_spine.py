# day03/calendar_spine.py
import duckdb

con = duckdb.connect("data/northmart.duckdb")

# 1. Weekly orders: date_trunc('week', ...) gives the Monday of each week
print(con.sql("""
    SELECT date_trunc('week', order_date)::DATE AS week_start, COUNT(*) AS n_orders
    FROM clean.orders
    GROUP BY week_start
    ORDER BY week_start
    LIMIT 5
"""))

# 2. The problem: a customer with no orders in a week has NO ROW for that week
print(con.sql("""
    SELECT customer_id, COUNT(DISTINCT date_trunc('week', order_date)) AS weeks_with_orders
    FROM clean.orders
    GROUP BY customer_id
    ORDER BY weeks_with_orders
    LIMIT 3
"""))

# 3. The fix: a calendar spine of every week, crossed with every customer
con.sql("""
    CREATE OR REPLACE TABLE clean.weeks AS
    SELECT
        week_start::DATE AS week_start,
        ROW_NUMBER() OVER (ORDER BY week_start) AS week_no
    FROM generate_series(DATE '2026-01-05', DATE '2026-04-20', INTERVAL 7 DAY) AS g(week_start)
""")
print(con.sql("SELECT * FROM clean.weeks ORDER BY week_no"))

n = con.sql("SELECT COUNT(*) FROM clean.customers CROSS JOIN clean.weeks").fetchall()[0][0]
print(f"Customers x weeks = {n:,} rows (4,000 x 16)")
con.close()
