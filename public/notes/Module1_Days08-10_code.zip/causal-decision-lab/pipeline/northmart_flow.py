# pipeline/northmart_flow.py
"""
The whole Module 1 pipeline as one Prefect flow:

    API health -> dlt load (raw) -> dbt build (models + contracts) -> publish marts

If any dbt contract fails, the flow stops BEFORE publishing, so analysts keep
the last good version of the data.

Run from the repository root (with the NorthMart API running):
    python pipeline/northmart_flow.py
    python pipeline/northmart_flow.py --as-of 2026-03-08     # replay a past week
"""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import requests
from prefect import flow, get_run_logger, task

ROOT = Path(__file__).resolve().parent.parent
DB = ROOT / "data" / "northmart.duckdb"
PUBLISHED = ROOT / "data" / "published"
API = "http://127.0.0.1:8000"
MARTS = ["panel_customer_week", "customer_features"]


def run(cmd: list[str], cwd: Path = ROOT) -> str:
    """Run a command; raise with its output if it fails."""
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)} failed:\n{result.stdout[-3000:]}\n{result.stderr[-3000:]}")
    return result.stdout


@task(retries=3, retry_delay_seconds=5)
def check_api() -> str:
    r = requests.get(f"{API}/health", timeout=10)
    r.raise_for_status()
    today = r.json()["today"]
    get_run_logger().info(f"API is up; its 'today' is {today}")
    return today


@task
def set_clock(as_of: str) -> None:
    run([sys.executable, "api/clock.py", as_of])


@task(retries=2, retry_delay_seconds=10)
def load_raw() -> str:
    out = run([sys.executable, "day05/northmart_pipeline.py"])
    lines = [l for l in out.splitlines() if l.startswith("raw.")]
    for line in lines:
        get_run_logger().info(line)
    return "\n".join(lines)


@task
def build_models() -> str:
    """dbt build = models + tests + contracts. Any error raises and stops the flow."""
    logger = get_run_logger()
    result = subprocess.run(["dbt", "--no-use-colors", "build", "--profiles-dir", "."],
                            cwd=ROOT / "transform", capture_output=True, text=True)
    lines = [l.split("  ", 1)[-1].strip() for l in result.stdout.splitlines()]   # drop timestamps
    summary = next((l for l in lines if l.startswith("Done. PASS=")), "no summary")
    for line in lines:
        if " FAIL " in line or " ERROR " in line or " WARN " in line:
            logger.warning(line)
    logger.info(summary)
    if result.returncode != 0:
        raise RuntimeError(f"dbt build failed, data NOT published. {summary}")
    return summary


@task
def publish(as_of: str, dbt_summary: str) -> dict:
    """Export the marts to Parquet with a small manifest describing this release."""
    PUBLISHED.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(DB), read_only=True)
    manifest = {
        "published_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "data_as_of": as_of,
        "dbt": dbt_summary,
        "tables": {},
    }
    for name in MARTS:
        path = PUBLISHED / f"{name}.parquet"
        con.sql(f"COPY marts.{name} TO '{path}' (FORMAT parquet)")
        n = con.sql(f"SELECT COUNT(*) FROM marts.{name}").fetchall()[0][0]
        manifest["tables"][name] = {"rows": n, "file": str(path.relative_to(ROOT))}
    con.close()
    (PUBLISHED / "manifest.json").write_text(json.dumps(manifest, indent=2))
    get_run_logger().info(f"Published {len(MARTS)} tables to {PUBLISHED.relative_to(ROOT)}")
    return manifest


@flow(name="northmart-causal-data-mart", log_prints=True)
def northmart_pipeline(as_of: str | None = None) -> dict:
    if as_of:
        set_clock(as_of)
    today = check_api()
    load_raw()
    summary = build_models()
    manifest = publish(today, summary)
    print(f"Data as of {today}: " + ", ".join(f"{k} {v['rows']:,} rows" for k, v in manifest["tables"].items()))
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--as-of", help="move the API clock to this date first (YYYY-MM-DD)")
    args = parser.parse_args()
    northmart_pipeline(args.as_of)
