# pipeline/serve.py
"""Run the pipeline on a schedule. Leave this running; stop with Ctrl+C."""
from northmart_flow import northmart_pipeline

if __name__ == "__main__":
    northmart_pipeline.serve(
        name="daily-6am",
        cron="0 6 * * *",                 # every day at 06:00
        tags=["northmart", "module-1"],
    )
