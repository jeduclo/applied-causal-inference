"""
Generate the NorthMart course dataset (simulated online retailer).

Run once from the repository root:
    python data/make_northmart.py

It writes four CSV files to data/raw/:
    customers.csv       one row per customer
    products.csv        one row per product
    orders.csv          one row per order line (deliberately a little messy)
    email_campaign.csv  one row per customer who received the spring email

Everything is simulated, so we KNOW the true causal effect of the email:
treated customers place about 15% more orders in the 8 weeks after it is sent.
Marketing did not send it at random: heavy shoppers were more likely to get it.
That targeting is what makes naive comparisons misleading later in the course.
"""

from datetime import date, timedelta
from pathlib import Path

import numpy as np
import polars as pl

SEED = 2026
N_CUSTOMERS = 4_000
FIRST_MONDAY = date(2026, 1, 5)     # week 1 starts here
N_WEEKS = 16                        # weeks 1-16, through Sunday 2026-04-26
CAMPAIGN_WEEK = 9                   # email sent Monday 2026-03-02
TRUE_EFFECT = 0.15                  # +15% order rate after the email

OUT = Path(__file__).parent / "raw"


def make_customers(rng: np.random.Generator) -> pl.DataFrame:
    n = N_CUSTOMERS
    regions = ["ON", "QC", "BC", "AB", "ATL"]
    region = rng.choice(regions, size=n, p=[0.38, 0.23, 0.15, 0.12, 0.12])
    is_loyalty = rng.random(n) < 0.30
    age = rng.integers(18, 76, size=n)
    signup_offset = rng.integers(0, 3 * 365, size=n)
    signup_date = [date(2023, 1, 1) + timedelta(days=int(d)) for d in signup_offset]

    # Latent shopping intensity (orders per week). Never shown to students directly.
    base_rate = rng.lognormal(mean=-1.6, sigma=0.6, size=n) * np.where(is_loyalty, 1.6, 1.0)

    return pl.DataFrame({
        "customer_id": [f"C{i:05d}" for i in range(1, n + 1)],
        "signup_date": signup_date,
        "region": region,
        "age": age,
        "is_loyalty": is_loyalty,
        "_base_rate": base_rate,
    })


def make_products(rng: np.random.Generator) -> pl.DataFrame:
    categories = {
        "Grocery": (4, 25), "Home": (15, 120), "Electronics": (40, 400),
        "Apparel": (20, 90), "Beauty": (8, 60),
    }
    rows = []
    pid = 1
    for cat, (lo, hi) in categories.items():
        for _ in range(8):
            rows.append({"product_id": f"P{pid:03d}", "category": cat,
                         "base_price": round(float(rng.uniform(lo, hi)), 2)})
            pid += 1
    return pl.DataFrame(rows)


def assign_campaign(rng: np.random.Generator, customers: pl.DataFrame) -> np.ndarray:
    """Targeted, not random: heavier shoppers and loyalty members are more likely to get the email."""
    z = np.log(customers["_base_rate"].to_numpy())
    z = (z - z.mean()) / z.std()
    logit = -1.2 + 1.1 * z + 0.6 * customers["is_loyalty"].to_numpy()
    p = 1 / (1 + np.exp(-logit))
    return rng.random(len(p)) < p


def make_orders(rng, customers, products, treated) -> pl.DataFrame:
    base = customers["_base_rate"].to_numpy()
    cust_ids = customers["customer_id"].to_numpy()
    prod_ids = products["product_id"].to_numpy()
    prices = products["base_price"].to_numpy()

    rows = []
    order_no = 1
    for week in range(1, N_WEEKS + 1):
        season = 1.0 + 0.10 * np.sin(2 * np.pi * week / 16)        # mild seasonality
        lift = np.where(treated & (week >= CAMPAIGN_WEEK), 1 + TRUE_EFFECT, 1.0)
        n_orders = rng.poisson(base * season * lift)
        week_start = FIRST_MONDAY + timedelta(weeks=week - 1)
        for i in np.nonzero(n_orders)[0]:
            for _ in range(n_orders[i]):
                k = rng.integers(len(prod_ids))
                discount = rng.choice([0, 0, 0, 10, 20])
                rows.append({
                    "order_id": f"O{order_no:06d}",
                    "customer_id": cust_ids[i],
                    "order_date": (week_start + timedelta(days=int(rng.integers(7)))).isoformat(),
                    "product_id": prod_ids[k],
                    "quantity": int(rng.integers(1, 4)),
                    "unit_price": round(prices[k] * (1 - discount / 100), 2),
                    "discount_pct": int(discount),
                    "status": "cancelled" if rng.random() < 0.03 else "completed",
                })
                order_no += 1
    orders = pl.DataFrame(rows)

    # Real data is messy: add ~1% exact duplicate rows (a double-loaded batch).
    dupes = orders.sample(fraction=0.01, seed=SEED)
    return pl.concat([orders, dupes]).sort("order_id")


def messy_regions(rng, customers: pl.DataFrame) -> pl.DataFrame:
    """Lower-case some codes, pad some with spaces, blank out ~2%."""
    region = customers["region"].to_list()
    for i in range(len(region)):
        u = rng.random()
        if u < 0.02:
            region[i] = None
        elif u < 0.06:
            region[i] = region[i].lower()
        elif u < 0.09:
            region[i] = f" {region[i]} "
    return customers.with_columns(pl.Series("region", region))


def main() -> None:
    rng = np.random.default_rng(SEED)
    OUT.mkdir(parents=True, exist_ok=True)

    customers = make_customers(rng)
    products = make_products(rng)
    treated = assign_campaign(rng, customers)
    orders = make_orders(rng, customers, products, treated)

    campaign = (customers.filter(pl.Series(treated))
                .select("customer_id")
                .with_columns(campaign_id=pl.lit("SPRING26"),
                              sent_date=pl.lit(FIRST_MONDAY + timedelta(weeks=CAMPAIGN_WEEK - 1))))

    messy_regions(rng, customers).drop("_base_rate").write_csv(OUT / "customers.csv")
    products.write_csv(OUT / "products.csv")
    orders.write_csv(OUT / "orders.csv")
    campaign.write_csv(OUT / "email_campaign.csv")

    print(f"customers:      {customers.height:>7,}")
    print(f"products:       {products.height:>7,}")
    print(f"order lines:    {orders.height:>7,}")
    print(f"emails sent:    {campaign.height:>7,}")
    print(f"Files written to {OUT}")


if __name__ == "__main__":
    main()
