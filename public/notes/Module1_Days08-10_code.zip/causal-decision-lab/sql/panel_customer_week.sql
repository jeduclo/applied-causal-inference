-- sql/panel_customer_week.sql
-- One row per customer per week (4,000 x 16 = 64,000 rows).
-- Grain: customer_id x week_start. Treatment: SPRING26 email, sent 2026-03-02 (week 9).

CREATE OR REPLACE TABLE marts.panel_customer_week AS
WITH weekly_orders AS (          -- 1. outcomes, only where orders exist
    SELECT customer_id,
           date_trunc('week', order_date)::DATE AS week_start,
           COUNT(DISTINCT order_id)             AS n_orders,
           SUM(revenue)                         AS revenue
    FROM clean.orders
    GROUP BY ALL
),
spine AS (                       -- 2. every customer in every week
    SELECT c.customer_id, w.week_start, w.week_no
    FROM clean.customers AS c
    CROSS JOIN clean.weeks AS w
),
filled AS (                      -- 3. attach outcomes; no order = 0, not NULL
    SELECT s.*,
           COALESCE(o.n_orders, 0) AS n_orders,
           COALESCE(o.revenue, 0)  AS revenue
    FROM spine AS s
    LEFT JOIN weekly_orders AS o USING (customer_id, week_start)
)
SELECT
    f.customer_id,
    f.week_start,
    f.week_no,
    f.week_no - 9                                       AS event_week,   -- 0 = email week
    -- treatment
    (e.customer_id IS NOT NULL)::INTEGER                AS treated,
    (f.week_start >= DATE '2026-03-02')::INTEGER        AS post,
    ((e.customer_id IS NOT NULL)
       AND f.week_start >= e.sent_date)::INTEGER        AS treated_post,
    -- outcomes
    f.n_orders,
    ROUND(f.revenue, 2)                                 AS revenue,
    -- pre-treatment covariates (fixed per customer)
    c.region,
    c.age,
    c.is_loyalty::INTEGER                               AS is_loyalty,
    SUM(f.n_orders) FILTER (WHERE f.week_no <= 8)
        OVER (PARTITION BY f.customer_id)               AS pre_orders,
    ROUND(SUM(f.revenue) FILTER (WHERE f.week_no <= 8)
        OVER (PARTITION BY f.customer_id), 2)           AS pre_revenue
FROM filled AS f
JOIN clean.customers AS c USING (customer_id)
LEFT JOIN clean.email_campaign AS e USING (customer_id)
ORDER BY f.customer_id, f.week_start;
