# day07/compare_panels.py
"""Mini-project check: the dbt panel must match the Day 3 panel exactly."""
import duckdb
import polars as pl

KEY = ["customer_id", "week_start"]

con = duckdb.connect("data/northmart.duckdb", read_only=True)
dbt_panel = con.sql("SELECT * FROM marts.panel_customer_week").pl().sort(KEY)
con.close()
day3_panel = pl.read_parquet("data/marts/panel_customer_week.parquet").sort(KEY)

print("rows    dbt:", dbt_panel.height, "| Day 3:", day3_panel.height)
print("columns match:", dbt_panel.columns == day3_panel.columns)

# Compare column by column, ignoring integer width (INT32 vs INT64)
problems = []
for col in day3_panel.columns:
    a, b = dbt_panel[col], day3_panel[col]
    if a.dtype.is_numeric():
        same = ((a.cast(pl.Float64) - b.cast(pl.Float64)).abs() < 1e-6).all()
    else:
        same = (a == b).all()
    if not same:
        problems.append(col)

print("columns that differ:", problems or "none")
assert not problems, "The dbt panel does not reproduce Day 3. Investigate before moving on."
print("The dbt model reproduces the Day 3 panel exactly.")
