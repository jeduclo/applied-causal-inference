# NorthMart data contracts

Each contract is a promise the data must keep before anyone estimates a causal effect from it.
"Error" stops the build and nothing downstream is rebuilt; "warn" reports and lets the analyst decide.

| ID | Contract | Where | Severity | Causal reason |
|---|---|---|---|---|
| C1 | Panel columns keep their names and types | `_marts.yml` (`contract: enforced`) | error | Estimation code downstream breaks or silently mis-casts |
| C2 | One row per customer per week | `unique_combination`, `assert_panel_is_complete` | error | Missing or doubled unit-weeks bias averages |
| C3 | Outcomes are 0, never NULL | `not_null` constraints | error | NULL outcomes silently drop units |
| C4 | Panel revenue equals order revenue | `assert_revenue_reconciles` | error | Outcomes lost between layers |
| C5 | Every order belongs to a known customer | `relationships` test on `stg_orders` | error | Orders can't be assigned to treatment or control |
| C6 | All emails sent on the official date | `assert_single_send_date` | error | Mixed timing breaks the pre/post split |
| C7 | No treatment before the email | `assert_no_treatment_before_email` | error | "Effects" before treatment are impossible |
| C8 | Treatment group fixed per customer | `assert_treatment_is_fixed` | error | Units switching groups break the comparison |
| C9 | Features use only pre-email data | `assert_features_do_not_leak` (time travel) | error | Post-treatment controls absorb the effect |
| C10 | Every week has orders | `assert_no_empty_weeks` | error | A missed load looks like a collapse in demand |
| C11 | Each region has 30+ treated and 30+ control customers | `warn_overlap_by_region` | warn | No overlap means no valid comparison in that group |

## Known warnings

- **C11, region UNKNOWN:** only 25 emailed customers have no recorded region. Analyses by region should
  pool or drop this group and say so.

## Fire-drill results (day08/break_things.py)

| Fault injected | Caught by | Outcome |
|---|---|---|
| 50 emails backdated two weeks | C6 | Build stopped; panel not rebuilt |
| Week 5 orders missing | C10 | Build stopped at the panel test |
| 100 orders loaded twice | (staging deduplication) | No damage: all contracts pass |
| 5 orders from an unknown customer | C5 | Build stopped; panel not rebuilt |
