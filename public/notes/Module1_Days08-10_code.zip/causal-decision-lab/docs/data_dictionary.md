# NorthMart data dictionary

| table | column | dtype | nulls | unique | example | role |
|---|---|---|---|---|---|---|
| customers | customer_id | String | 0 | 4000 | C00001 | unit |
| customers | signup_date | Date | 0 | 1058 | 2025-07-09 | covariate (pre-treatment) |
| customers | region | String | 74 | 16 | ON | covariate (pre-treatment) |
| customers | age | Int64 | 0 | 58 | 21 | covariate (pre-treatment) |
| customers | is_loyalty | Boolean | 0 | 2 | False | covariate (pre-treatment) |
| email_campaign | customer_id | String | 0 | 1279 | C00004 | unit |
| email_campaign | campaign_id | String | 0 | 1 | SPRING26 | treatment label |
| email_campaign | sent_date | Date | 0 | 1 | 2026-03-02 | treatment timing |
| orders | order_id | String | 0 | 18359 | O000001 | identifier |
| orders | customer_id | String | 0 | 3738 | C00003 | unit |
| orders | order_date | Date | 0 | 112 | 2026-01-08 | time |
| orders | product_id | String | 0 | 40 | P011 | identifier |
| orders | quantity | Int64 | 0 | 3 | 1 | outcome ingredient |
| orders | unit_price | Float64 | 0 | 120 | 61.62 | outcome ingredient |
| orders | discount_pct | Int64 | 0 | 3 | 20 | possible mediator / other treatment |
| orders | status | String | 0 | 2 | completed | filter |
| products | product_id | String | 0 | 40 | P001 | identifier |
| products | category | String | 0 | 5 | Grocery | covariate |
| products | base_price | Float64 | 0 | 40 | 23.73 | covariate |
