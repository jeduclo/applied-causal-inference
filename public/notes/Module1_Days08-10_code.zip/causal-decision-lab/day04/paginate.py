# day04/paginate.py
import requests

BASE = "http://127.0.0.1:8000"
HEADERS = {"X-API-Key": "northmart-demo-key"}


def fetch_all(endpoint: str, page_size: int = 1000) -> list[dict]:
    """Follow next_page until the API says there is no more."""
    rows: list[dict] = []
    page = 1
    while page is not None:
        r = requests.get(f"{BASE}/{endpoint}", headers=HEADERS,
                         params={"page": page, "page_size": page_size}, timeout=30)
        r.raise_for_status()
        body = r.json()
        rows.extend(body["data"])
        print(f"  {endpoint}: page {page} -> {len(body['data'])} rows")
        page = body["next_page"]
    return rows


if __name__ == "__main__":
    orders = fetch_all("orders")
    print("Orders fetched:", len(orders))
