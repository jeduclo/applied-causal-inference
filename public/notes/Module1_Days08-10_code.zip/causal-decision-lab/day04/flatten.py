# day04/flatten.py
import polars as pl

from paginate import fetch_all

orders_json = fetch_all("orders")

# 1. Polars turns a list of dicts into a DataFrame; nested dicts become a Struct column
orders = pl.DataFrame(orders_json)
print(orders.schema)

# 2. unnest() spreads the struct's fields into ordinary columns
flat = orders.unnest("line").with_columns(pl.col("order_date").str.to_date())
print(flat.head(3))

# 3. Reconcile with the CSV we used on Days 1-3
csv = pl.read_csv("data/raw/orders.csv", try_parse_dates=True)
print("API rows:", flat.height, "| CSV rows:", csv.height)
same = flat.select(csv.columns).sort("order_id").equals(csv.sort("order_id"))
print("Identical to the CSV:", same)
