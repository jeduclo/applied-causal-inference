# day04/api_client.py
"""Mini-project: a small, reusable client for the NorthMart API."""
import os
from pathlib import Path

import polars as pl
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BASE = os.environ.get("NORTHMART_API_URL", "http://127.0.0.1:8000")
OUT = Path("data/api")


def make_session() -> requests.Session:
    """One session for all calls: shared headers, automatic retries on server errors."""
    key = os.environ.get("NORTHMART_API_KEY")
    if not key:
        raise RuntimeError("Set NORTHMART_API_KEY first, e.g.  export NORTHMART_API_KEY=northmart-demo-key")
    session = requests.Session()
    session.headers["X-API-Key"] = key
    retry = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
    session.mount("http://", HTTPAdapter(max_retries=retry))
    session.mount("https://", HTTPAdapter(max_retries=retry))
    return session


def fetch_pages(session: requests.Session, endpoint: str, **params):
    """Yield one page of records at a time (a generator)."""
    page = 1
    while page is not None:
        r = session.get(f"{BASE}/{endpoint}", params={"page": page, "page_size": 1000, **params}, timeout=30)
        r.raise_for_status()
        body = r.json()
        yield body["data"]
        page = body.get("next_page")


def fetch_all(session: requests.Session, endpoint: str, **params) -> list[dict]:
    return [row for page in fetch_pages(session, endpoint, **params) for row in page]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    s = make_session()

    customers = pl.DataFrame(fetch_all(s, "customers")).unnest("profile")
    orders = pl.DataFrame(fetch_all(s, "orders")).unnest("line")
    products = pl.DataFrame(s.get(f"{BASE}/products", timeout=30).json()["data"])
    recipients = pl.DataFrame(s.get(f"{BASE}/campaigns/SPRING26/recipients", timeout=30).json()["data"])

    for name, df in [("customers", customers), ("orders", orders),
                     ("products", products), ("recipients", recipients)]:
        df.write_parquet(OUT / f"{name}.parquet")
        print(f"{name:<11} {df.height:>7,} rows  -> {OUT / name}.parquet")


if __name__ == "__main__":
    main()
