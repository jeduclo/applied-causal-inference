# day04/first_request.py
import requests

BASE = "http://127.0.0.1:8000"

# 1. A public endpoint: no key needed
r = requests.get(f"{BASE}/health", timeout=10)
print(r.status_code)        # 200 = OK
print(r.json())             # the body, turned into a Python dict

# 2. A protected endpoint without a key
r = requests.get(f"{BASE}/products", timeout=10)
print(r.status_code, r.json())   # 401 = not authorised

# 3. The same request with the key in a header
r = requests.get(f"{BASE}/products", headers={"X-API-Key": "northmart-demo-key"}, timeout=10)
r.raise_for_status()        # stop with an error if the status is not 2xx
products = r.json()["data"]
print(len(products), "products; first one:", products[0])
