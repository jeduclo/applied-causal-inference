# day04/json_basics.py
import json

import requests

BASE = "http://127.0.0.1:8000"
HEADERS = {"X-API-Key": "northmart-demo-key"}

r = requests.get(f"{BASE}/orders", headers=HEADERS, params={"page_size": 2}, timeout=10)
body = r.json()

# 1. The top level is a dict: some metadata plus a list of records
print(list(body.keys()))
print("total orders:", body["total"], "| next page:", body["next_page"])

# 2. Pretty-print one record to see its shape
first = body["data"][0]
print(json.dumps(first, indent=2))

# 3. Nested fields: a dict inside a dict
print("quantity:", first["line"]["quantity"])
revenue = first["line"]["quantity"] * first["line"]["unit_price"]
print(f"revenue: {revenue:.2f}")

# 4. params= builds the query string for you
print(r.url)
