# day09/retries_demo.py
from prefect import flow, task
from prefect.runtime import task_run


@task(retries=3, retry_delay_seconds=2)
def call_flaky_service() -> str:
    attempt = task_run.run_count
    print(f"attempt {attempt}")
    if attempt < 3:                       # fails twice, then works: like a busy API
        raise ConnectionError("service temporarily unavailable")
    return "data received"


@flow(log_prints=True)
def resilient():
    print(call_flaky_service())


if __name__ == "__main__":
    resilient()
