# day09/hello_flow.py
import duckdb
from prefect import flow, task


@task
def count_orders(week_start: str) -> int:
    con = duckdb.connect("data/northmart.duckdb", read_only=True)
    n = con.sql(f"""
        SELECT COALESCE(SUM(n_orders), 0) FROM marts.panel_customer_week
        WHERE week_start = DATE '{week_start}'
    """).fetchall()[0][0]
    con.close()
    return int(n)


@task
def describe(week_start: str, n: int) -> str:
    return f"Week of {week_start}: {n:,} orders"


@flow(log_prints=True)
def weekly_summary(week_start: str = "2026-03-02"):
    n = count_orders(week_start)
    message = describe(week_start, n)
    print(message)
    return message


if __name__ == "__main__":
    weekly_summary()
    weekly_summary("2026-02-23")
